# InventarioAppRoomFull

Este ZIP incluye:
- Código completo del proyecto.
- APK compilado (debug).
- Instrucciones para compilar en Gitpod y abrir en Android Studio.

## Cómo instalar el APK
1. Descarga el ZIP y extrae.
2. Conecta tu dispositivo con depuración USB.
3. Instala el APK:
```
adb install app/build/outputs/apk/debug/app-debug.apk
```
